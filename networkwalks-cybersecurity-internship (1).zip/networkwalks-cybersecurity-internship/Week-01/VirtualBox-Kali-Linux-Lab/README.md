# Week 1 — Cybersecurity Testing Lab: VirtualBox + Kali Linux

**Program:** NetworkWalks Cybersecurity Internship  
**Module:** WK1-PM1 — Lab Setup: VirtualBox and Kali Linux  
**Status:** Kali VM setup and boot documented with screenshots; remaining assignment-specific network and integration checks are not yet evidenced.

## Objective

Build a virtual cybersecurity practice environment with Oracle VirtualBox and Kali Linux. Configure a custom NAT Network in the `10.0.0.0/24` subnet, assign Kali Linux the address `10.0.0.2/24`, and prepare the VM for future controlled security exercises.

## Tools and environment

- Oracle VirtualBox — virtualization platform
- Kali Linux — security testing virtual machine
- 7-Zip — optional archive extraction tool
- Custom VirtualBox NAT Network — `10.0.0.0/24`

## Assignment target configuration (not all verified)

| Component | Specification |
|---|---|
| Virtualization | Oracle VirtualBox |
| Guest OS | Kali Linux |
| Network mode | NAT Network (custom) |
| Subnet | `10.0.0.0/24` |
| Kali static IPv4 | `10.0.0.2/24` |
| Gateway | Verify against the configured VirtualBox NAT Network gateway |
| Internet | Connectivity required |
| VM integration | Shared clipboard and drag-and-drop enabled |
| Shared folder | Host downloads directory shared with guest |
| Recovery | VM snapshot |

## Lab architecture

```text
Host computer
└── Oracle VirtualBox
    └── Custom NAT Network: 10.0.0.0/24
        └── Kali Linux VM: 10.0.0.2/24
            └── Internet via VirtualBox NAT
```

Additional Windows and Android VMs appear in the assignment as optional future extensions, not as required evidence for this Week 1 write-up.

## Assignment implementation checklist (not all verified)

1. Install Oracle VirtualBox on the host machine.
2. Create a custom NAT Network using the `10.0.0.0/24` subnet.
3. Download and import a Kali Linux virtual machine.
4. Set the Kali VM network adapter to **NAT Network**, selecting the custom network.
5. Configure Kali Linux with static IPv4 `10.0.0.2/24`, the appropriate gateway, and DNS settings.
6. Enable shared clipboard and drag-and-drop in VM settings.
7. Configure a shared folder pointing to the host's Downloads directory.
8. Start Kali and verify IP configuration and internet connectivity.
9. Take a VM snapshot once the setup is working.

## Verification commands

Use these commands to validate the configuration and capture screenshots. They are provided for reproducibility; outputs have not been supplied in this repository.

```bash
ip -br addr
ip route
ping -c 4 10.0.0.1
ping -c 4 8.8.8.8
ping -c 4 kali.org
```

**Note:** `10.0.0.1` is an example gateway address. Check the actual NAT Network configuration before running the gateway test. A successful DNS-name ping helps demonstrate name resolution, while an IP ping helps isolate routing/connectivity issues.

## Actual screenshots and evidence

These screenshots document the virtual machines and a successful Kali Linux boot. They do **not** yet verify the full assignment configuration.

### VirtualBox Manager showing Kali Linux and Metasploitable 2 virtual machines.

![VirtualBox Manager showing Kali Linux and Metasploitable 2 virtual machines.](screenshots/01-virtualbox-vms.png)

*VirtualBox Manager showing Kali Linux and Metasploitable 2 virtual machines.*

### Kali VM network settings

![Kali VM network settings: Adapter 1 uses NAT, not the assignment’s requested custom NAT Network.](screenshots/02-kali-network-settings.png)

*Kali VM network settings: Adapter 1 uses NAT, not the assignment’s requested custom NAT Network.*

### Kali VM allocated 4096 MB of memory.

![Kali VM allocated 4096 MB of memory.](screenshots/03-kali-system-settings.png)

*Kali VM allocated 4096 MB of memory.*

### Kali Linux booting in VirtualBox.

![Kali Linux booting in VirtualBox.](screenshots/04-kali-boot.png)

*Kali Linux booting in VirtualBox.*

### Kali Linux graphical desktop after boot.

![Kali Linux graphical desktop after boot.](screenshots/05-kali-desktop.png)

*Kali Linux graphical desktop after boot.*

**Verification still needed:** The screenshot shows Adapter 1 set to standard **NAT**, with Adapter 2 shown as **Host-only Adapter** in the manager. The course specifies **NAT Network** on `10.0.0.0/24`; these are different modes. No supplied screenshot confirms static IP `10.0.0.2/24`, internet/DNS tests, clipboard and drag-and-drop, shared folders, or a snapshot. Capture those only if you configure and verify them. Metasploitable 2 appears in VirtualBox Manager but is powered off; no interaction or security testing is evidenced.

## Troubleshooting notes

If the Kali VM cannot access the internet, verify that the NAT Network exists, that the VM is attached to the correct network, and that no other VM uses `10.0.0.2`. Check gateway and DNS settings. The course material also suggests resetting the NetworkManager connection when applicable:

```bash
sudo nmcli connection modify "Wired connection 1" ipv4.dad-timeout 0
sudo nmcli connection down "Wired connection 1"
sudo nmcli connection up "Wired connection 1"
```

Use the actual connection name shown by `nmcli connection show` if it differs. These commands are troubleshooting options from the training handout, not a claim that I encountered or resolved this specific issue.

## Skills reinforced

- Virtualization and virtual machine configuration
- IPv4 addressing and subnetting
- NAT networking and routing basics
- Linux network inspection and connectivity troubleshooting
- VM snapshots and reproducible lab documentation

## Next steps

Use this isolated practice environment for authorized network-security exercises, additional test VMs, and future internship modules.

## Acknowledgment

Lab brief and architecture adapted from the NetworkWalks WK1-PM1 training assignment. This README is my portfolio documentation, not a reproduction of the training slides.
