# NetworkWalks Cybersecurity Internship Portfolio

This repository documents my hands-on cybersecurity internship projects at NetworkWalks, including lab configurations, technical observations, screenshots, and lessons learned.

## Project index

| Week | Project | Documentation |
|---|---|---|
| 1 | VirtualBox and Kali Linux Cybersecurity Lab | [View Week 1](Week-01/VirtualBox-Kali-Linux-Lab/README.md) |

> Documentation reflects work completed previously and organized into a portfolio during the internship. Screenshots and test results should be added from my own lab.

### Week 1 evidence

Five screenshots are included in `Week-01/VirtualBox-Kali-Linux-Lab/screenshots/`. They confirm VirtualBox setup and Kali boot; the requested NAT Network, static IP, and connectivity checks still need separate verification.
